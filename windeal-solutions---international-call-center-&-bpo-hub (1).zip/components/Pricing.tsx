
import React, { useState } from 'react';
import { Check, Flame, Zap, Database, ShieldCheck, BarChart3, Clock } from 'lucide-react';
import { ViewType } from '../App';

interface PricingPlan {
  name: string;
  price: string;
  desc: string;
  features: string[];
  cta: string;
  popular: boolean;
  icon?: React.ReactNode;
}

interface PricingProps {
  onNavigate: (view: ViewType) => void;
}

const Pricing: React.FC<PricingProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'bpo' | 'mca'>('bpo');

  const bpoPlans: PricingPlan[] = [
    {
      name: "Starter Pilot",
      price: "$1,200/mo",
      desc: "Ideal for startups looking to validate new outbound campaigns.",
      features: [
        "1 Dedicated Agent (8/5)",
        "Standard CRM Integration",
        "Weekly Progress Reports",
        "Campaign Script Design",
        "Quality Assurance Audit"
      ],
      cta: "Launch Pilot",
      popular: false
    },
    {
      name: "Scale Engine",
      price: "$2,200/mo",
      desc: "Our most popular plan for high-velocity outbound scaling.",
      features: [
        "2 Dedicated Agents (8/5)",
        "Advanced Lead Qualification",
        "Daily Performance Dashboard",
        "Active Campaign Management",
        "Priority Slack Channel",
        "Predictive Dialer Access"
      ],
      cta: "Get Started Now",
      popular: true
    },
    {
      name: "Global Ops",
      price: "Custom Quote",
      desc: "Full-scale enterprise managed operations with zero overhead.",
      features: [
        "Dedicated Team (5-20+)",
        "On-site Project Director",
        "Omni-channel Support Hub",
        "White-label Integration",
        "Dedicated IT Infrastructure",
        "Bespoke ROI Optimization"
      ],
      cta: "Request Proposal",
      popular: false
    }
  ];

  const mcaPlans: PricingPlan[] = [
    {
      name: "Standard Data",
      price: "Starts $0.50/Lead",
      icon: <Database className="w-6 h-6" />,
      desc: "Cost-effective verified merchant lists for volume dialing.",
      features: [
        "Verified Merchant Contacts",
        "Industry & Debt Filtered",
        "Opt-in Marketing Data",
        "Updated Lead Lists",
        "Direct CSV Export"
      ],
      cta: "Inquire Volume",
      popular: false
    },
    {
      name: "Live Transfers",
      price: "$55 - $85 / ea",
      icon: <Flame className="w-6 h-6" />,
      desc: "Instant hot-keys connected directly to your closers.",
      features: [
        "Verified Merchant Interest",
        "Minimum $15k+ Monthly Revenue",
        "100% Connect Rate Guarantee",
        "Direct Call Patching",
        "Replacement Policy",
        "Live Call Recording"
      ],
      cta: "Order Transfers",
      popular: true
    },
    {
      name: "Verified Apps",
      price: "Custom Pricing",
      icon: <Zap className="w-6 h-6" />,
      desc: "Full submission packages with supporting documents.",
      features: [
        "Completed 1-Page Application",
        "Last 3-4 Months Statements",
        "Credit Score Qualified",
        "Exclusive Leads",
        "Direct CRM Injection",
        "Dedicated Account Mgr"
      ],
      cta: "Get Packages",
      popular: false
    }
  ];

  const currentPlans = activeTab === 'bpo' ? bpoPlans : mcaPlans;

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-blue-600 font-bold tracking-widest text-sm mb-4 uppercase">PRICING & ENGAGEMENT</div>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6 uppercase tracking-tight">Value-Driven Scale</h2>
          <p className="text-slate-600 text-lg font-medium leading-relaxed">
            Offshore cost efficiency meet Western quality standards. Transparent pricing models designed to maximize your margin.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex justify-center mb-16">
          <div className="inline-flex bg-slate-100 p-1.5 rounded-2xl border border-slate-200 shadow-inner">
            <button
              onClick={() => setActiveTab('bpo')}
              className={`px-8 py-3 rounded-xl font-bold text-sm transition-all ${
                activeTab === 'bpo' 
                ? 'bg-white text-blue-600 shadow-md' 
                : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              BPO Retainers
            </button>
            <button
              onClick={() => setActiveTab('mca')}
              className={`px-8 py-3 rounded-xl font-bold text-sm transition-all ${
                activeTab === 'mca' 
                ? 'bg-white text-blue-600 shadow-md' 
                : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Lead Packages
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {currentPlans.map((plan, i) => (
            <div 
              key={i} 
              className={`relative bg-white p-10 rounded-[32px] shadow-2xl transition-all hover:-translate-y-2 border-2 flex flex-col ${
                plan.popular ? 'border-blue-600 ring-8 ring-blue-600/5' : 'border-slate-50'
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-cyan-500 text-white text-[10px] font-black px-6 py-2 rounded-full uppercase tracking-widest shadow-lg shadow-cyan-200">
                  {activeTab === 'mca' ? 'High Volume' : 'Best ROI'}
                </div>
              )}
              
              {plan.icon && (
                <div className="mb-6 bg-blue-50 w-12 h-12 rounded-xl flex items-center justify-center text-blue-600">
                  {plan.icon}
                </div>
              )}

              <h3 className="text-2xl font-black text-slate-900 mb-2 uppercase tracking-tight">{plan.name}</h3>
              <p className="text-slate-500 text-sm mb-8 leading-relaxed h-12 font-medium">{plan.desc}</p>
              <div className="text-3xl font-black text-blue-600 mb-10">{plan.price}</div>
              
              <ul className="space-y-5 mb-12 flex-grow">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-4 text-slate-700 text-sm font-bold tracking-tight">
                    <div className="bg-blue-100 p-1 rounded-full shrink-0">
                      <Check className="w-4 h-4 text-blue-600" />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => onNavigate('contact')}
                className={`block w-full text-center py-5 rounded-2xl font-black transition-all uppercase tracking-widest text-[11px] ${
                  plan.popular 
                    ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-xl shadow-blue-200' 
                    : 'bg-slate-900 text-white hover:bg-slate-800'
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>

        {/* Value Add Section */}
        <div className="mt-24 grid md:grid-cols-3 gap-12 border-t border-slate-100 pt-16">
          {[
            { icon: <ShieldCheck className="w-6 h-6 text-blue-600" />, title: "Included QA", desc: "Every call is recorded and audited by our internal QA team to ensure 100% compliance." },
            { icon: <BarChart3 className="w-6 h-6 text-cyan-600" />, title: "Daily Reporting", desc: "Detailed Excel/CSV and dashboard reports sent daily so you can track your campaign velocity." },
            { icon: <Clock className="w-6 h-6 text-indigo-600" />, title: "Night Shift Focus", desc: "Our agents work while you sleep, ensuring high-energy outreach during North American business hours." }
          ].map((v, i) => (
            <div key={i} className="flex gap-6 items-start">
               <div className="p-4 bg-slate-50 rounded-2xl">{v.icon}</div>
               <div>
                  <h4 className="text-lg font-black text-slate-900 mb-2 uppercase tracking-tight">{v.title}</h4>
                  <p className="text-slate-500 text-sm font-medium leading-relaxed">{v.desc}</p>
               </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;
