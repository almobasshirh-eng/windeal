
import React from 'react';
import { ArrowRight, Code2, Globe, Shield, Star } from 'lucide-react';
import { ViewType } from '../App';

interface HeroProps {
  onNavigate: (view: ViewType) => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <div className="relative min-h-screen flex items-center pt-24 pb-12 overflow-hidden bg-white">
      {/* Dynamic Grid Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-50/50 via-white to-white"></div>
        <div className="w-full h-full grid-bg opacity-40"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-full glass border-blue-500/20 text-blue-600 text-[10px] font-black tracking-widest mb-10 animate-in uppercase shadow-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 animate-pulse"></span>
              High-Conversion BPO Hub
            </div>
            
            <h1 className="text-6xl lg:text-8xl font-black text-slate-900 leading-[0.95] mb-8 animate-in" style={{ animationDelay: '0.1s' }}>
              SCALE. <br />
              <span className="text-gradient">DOMINATE.</span>
            </h1>
            
            <p className="text-xl text-slate-600 mb-10 leading-relaxed font-medium animate-in" style={{ animationDelay: '0.2s' }}>
              We architect high-performance <span className="text-blue-600 font-bold">Sales & Support Pipelines</span> for North American businesses. WinDeal Solutions delivers elite communication talent to maximize your ROI.
            </p>

            <div className="flex flex-col sm:flex-row gap-5 mb-12 animate-in" style={{ animationDelay: '0.3s' }}>
              <button
                onClick={() => onNavigate('contact')}
                className="group relative px-10 py-5 bg-blue-600 rounded-3xl overflow-hidden shadow-2xl shadow-blue-600/30 transition-all hover:scale-105 active:scale-95"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative z-10 flex items-center justify-center gap-3 text-white font-black tracking-widest text-sm">
                  GET FREE QUOTE <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </span>
              </button>
              <button
                onClick={() => onNavigate('services')}
                className="px-10 py-5 glass rounded-3xl text-slate-900 font-black tracking-widest text-sm flex items-center justify-center gap-3 border-blue-100 hover:border-blue-200 transition-all shadow-sm"
              >
                VIEW PACKAGES
              </button>
            </div>

            {/* Trust Signals */}
            <div className="flex items-center gap-6 mb-16 animate-in" style={{ animationDelay: '0.4s' }}>
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-slate-100 overflow-hidden">
                    <img src={`https://i.pravatar.cc/100?img=${i + 15}`} alt="Client" />
                  </div>
                ))}
              </div>
              <div className="text-sm">
                <div className="flex items-center gap-1 text-cyan-500 mb-1">
                  {[1, 2, 3, 4, 5].map(i => <Star key={i} className="w-3 h-3 fill-current" />)}
                </div>
                <div className="font-bold text-slate-900">Trusted by 50+ Global Brands</div>
              </div>
            </div>

            <div className="flex gap-12 animate-in" style={{ animationDelay: '0.5s' }}>
              {[
                { icon: <Globe className="w-5 h-5 text-blue-500" />, label: "USA & CANADA" },
                { icon: <Shield className="w-5 h-5 text-cyan-500" />, label: "TCPA COMPLIANT" },
                { icon: <Code2 className="w-5 h-5 text-indigo-500" />, label: "24/7 OPERATIONS" },
              ].map((item, i) => (
                <div key={i} className="flex flex-col gap-3">
                  <div className="p-3 bg-white rounded-2xl colorful-shadow w-fit">{item.icon}</div>
                  <div className="text-[10px] font-black tracking-[0.2em] text-slate-400 uppercase">{item.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative hidden lg:block animate-in" style={{ animationDelay: '0.5s' }}>
            <div className="relative z-10 group">
              <div className="absolute -inset-6 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-[50px] blur-3xl opacity-20 group-hover:opacity-30 transition-opacity"></div>
              <div className="glass p-3 rounded-[50px] border-white shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1549923746-c502d488b3ea?auto=format&fit=crop&q=80&w=1200"
                  alt="WinDeal Call Center Floor"
                  className="w-full rounded-[40px] object-cover h-[550px]"
                />
              </div>
              
              {/* Floating UI Elements */}
              <div 
                className="absolute -top-12 -right-12 glass p-8 rounded-[32px] border-blue-100 animate-float shadow-2xl text-center cursor-pointer hover:scale-110 transition-transform"
                onClick={() => onNavigate('why-us')}
              >
                <div className="bg-gradient-to-r from-blue-600 to-indigo-500 bg-clip-text text-transparent text-4xl font-black mb-1">15%</div>
                <div className="text-[10px] text-slate-500 font-black tracking-widest uppercase">CONVERSION UPLIFT</div>
              </div>
              
              <div 
                className="absolute -bottom-10 -left-10 glass p-8 rounded-[32px] border-cyan-100 animate-float shadow-2xl cursor-pointer hover:scale-110 transition-transform" 
                style={{ animationDelay: '1s' }}
                onClick={() => onNavigate('contact')}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-3 h-3 rounded-full bg-blue-500 animate-pulse"></div>
                  <div className="text-[10px] text-slate-500 font-black tracking-widest uppercase">LIVE CAMPAIGNS</div>
                </div>
                <div className="flex gap-1.5 items-end h-8">
                  {[30, 60, 40, 90, 50, 20, 70, 45].map((h, i) => (
                    <div key={i} className="w-1.5 bg-gradient-to-t from-blue-600 to-cyan-500 rounded-full" style={{ height: h + '%' }}></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
