
import React from 'react';
import { ArrowLeft, CheckCircle, Globe, Zap, ShieldCheck, BarChart3, Clock, Rocket, Target, Headphones, ClipboardCheck } from 'lucide-react';

interface PageProps {
  onBack: () => void;
}

const WhyUsPage: React.FC<PageProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen pt-32 pb-24 bg-white animate-in fade-in duration-500">
      <div className="container mx-auto px-6">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-blue-600 font-black text-xs tracking-widest uppercase mb-12 hover:translate-x-[-4px] transition-transform"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Overview
        </button>

        <div className="max-w-4xl mb-24">
          <h1 className="text-5xl lg:text-8xl font-black text-slate-900 leading-[0.9] tracking-tighter mb-10 uppercase">
            WHY WE <span className="text-gradient">DOMINATE.</span>
          </h1>
          <p className="text-xl text-slate-500 font-medium leading-relaxed">
            WinDeal Solutions isn't just a choice; it's a strategic upgrade. We combine the cost-efficiency of Bangladesh with the high-output standards of a North American board room.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-20 mb-32">
          <div className="space-y-16">
            {[
              { icon: <Globe />, title: "USA ACCENT ALIGNMENT", desc: "Our staff doesn't just speak English; they understand the cultural nuances of the US market, ensuring a native-level experience for your prospects." },
              { icon: <BarChart3 />, title: "DATA-DRIVEN PRECISION", desc: "Every campaign is backed by real-time analytics. We pivot based on performance data to ensure your Cost Per Acquisition stays at record lows." },
              { icon: <ShieldCheck />, title: "IRON-CLAD COMPLIANCE", desc: "We adhere strictly to TCPA, HIPAA, and international data standards. Your campaign security and legal safety are our highest priorities." }
            ].map((item, i) => (
              <div key={i} className="flex gap-8 group">
                <div className="bg-blue-50 text-blue-600 p-5 rounded-3xl h-fit group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                  {React.cloneElement(item.icon as React.ReactElement<any>, { className: "w-8 h-8" })}
                </div>
                <div>
                  <h3 className="text-xl font-black text-slate-900 mb-4 tracking-widest uppercase">{item.title}</h3>
                  <p className="text-slate-500 leading-relaxed font-medium">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="bg-slate-900 rounded-[50px] p-12 lg:p-20 text-white relative overflow-hidden shadow-2xl">
             <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-[100px] -mr-40 -mt-40"></div>
             <h3 className="text-3xl font-black mb-12 uppercase tracking-tight relative z-10">Our Success Framework</h3>
             <div className="space-y-10 relative z-10">
                <div className="flex items-center gap-6">
                   <div className="text-4xl font-black text-blue-400">01</div>
                   <div>
                      <div className="font-black text-sm uppercase tracking-widest mb-1">Onboarding</div>
                      <div className="text-slate-400 text-sm">Rapid campaign setup and CRM integration in <span className="text-white font-bold">48 hours</span>.</div>
                   </div>
                </div>
                <div className="flex items-center gap-6">
                   <div className="text-4xl font-black text-cyan-400">02</div>
                   <div>
                      <div className="font-black text-sm uppercase tracking-widest mb-1">Execution</div>
                      <div className="text-slate-400 text-sm">Multi-tier QA monitoring with <span className="text-white font-bold">98% conversion accuracy</span>.</div>
                   </div>
                </div>
                <div className="flex items-center gap-6">
                   <div className="text-4xl font-black text-indigo-400">03</div>
                   <div>
                      <div className="font-black text-sm uppercase tracking-widest mb-1">Scale</div>
                      <div className="text-slate-400 text-sm">Modular team expansion with <span className="text-white font-bold">zero operational downtime</span>.</div>
                   </div>
                </div>
             </div>
          </div>
        </div>

        {/* Visual Process Section */}
        <div className="py-24 bg-slate-50 rounded-[60px] p-12 lg:p-24 border border-slate-100 mb-32">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-black text-slate-900 mb-6 uppercase tracking-tight">How We Work</h2>
            <p className="text-slate-500 font-medium text-lg max-w-2xl mx-auto">Our proven 4-step pipeline ensures every client campaign is launched with surgical precision.</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: <Target className="w-8 h-8"/>, title: "Discovery", desc: "We analyze your sector, goals, and target demographic." },
              { icon: <Headphones className="w-8 h-8"/>, title: "Training", desc: "Agents undergo intensive campaign-specific immersion." },
              { icon: <Rocket className="w-8 h-8"/>, title: "Launch", desc: "Live operations begin with real-time management oversight." },
              { icon: <ClipboardCheck className="w-8 h-8"/>, title: "Optimization", desc: "Daily data audits to refine scripts and conversion." }
            ].map((step, i) => (
              <div key={i} className="relative group text-center p-8 bg-white rounded-[40px] shadow-sm hover:shadow-xl transition-all border border-slate-100">
                <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl mx-auto flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all">
                  {step.icon}
                </div>
                <h4 className="text-lg font-black text-slate-900 mb-2 uppercase tracking-tight">{step.title}</h4>
                <p className="text-slate-500 text-xs font-medium leading-relaxed">{step.desc}</p>
                {i < 3 && <div className="hidden lg:block absolute top-1/2 -right-4 w-8 h-px bg-slate-200"></div>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhyUsPage;
