
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { Mic, MicOff, Volume2, Info, Activity, Shield, Zap, Globe } from 'lucide-react';

const VoiceAIExperience: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [audioLevel, setAudioLevel] = useState(0);

  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Decoding functions for PCM
  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const stopSession = () => {
    if (sessionRef.current) {
      sessionRef.current.close?.();
      sessionRef.current = null;
    }
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    setIsActive(false);
    setIsConnecting(false);
  };

  const startVoiceExperience = async () => {
    if (isActive) {
      stopSession();
      return;
    }

    setIsConnecting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
      
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputAudioContext;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);
            const source = inputAudioContext.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              
              // Simple level visualizer logic
              let sum = 0;
              for(let i=0; i<inputData.length; i++) sum += inputData[i] * inputData[i];
              setAudioLevel(Math.sqrt(sum / inputData.length));

              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) int16[i] = inputData[i] * 32768;
              
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };

              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
          },
          onmessage: async (message) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
              const source = outputAudioContext.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputAudioContext.destination);
              source.addEventListener('ended', () => sourcesRef.current.delete(source));
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }

            if (message.serverContent?.outputTranscription) {
              setTranscript(prev => (prev + ' ' + message.serverContent.outputTranscription.text).slice(-200));
            }
          },
          onerror: (e) => {
            console.error('Session error:', e);
            stopSession();
          },
          onclose: () => {
            stopSession();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
          },
          systemInstruction: 'You are a Senior Sales Trainer at WinDeal Solutions, an international call center in Bangladesh. Your tone is professional, encouraging, and highly articulate. You are demonstrating WinDeals linguistic and technical capability. Keep responses concise and focused on how WinDeal can scale businesses.',
          outputAudioTranscription: {}
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (error) {
      console.error('Failed to start session:', error);
      setIsConnecting(false);
    }
  };

  useEffect(() => {
    return () => stopSession();
  }, []);

  return (
    <section className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Visual background elements */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div className="h-full w-full grid-bg"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white/5 backdrop-blur-3xl rounded-[60px] border border-white/10 p-8 lg:p-16 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8">
              <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-emerald-500 shadow-[0_0_15px_#10b981]' : 'bg-slate-700'} transition-all duration-500`}></div>
            </div>

            <div className="flex flex-col lg:flex-row gap-16 items-center">
              <div className="lg:w-1/2 space-y-8 text-center lg:text-left">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-500/10 border border-teal-500/20 text-teal-400 text-[10px] font-black tracking-[0.3em] rounded-full uppercase">
                  <Activity className="w-4 h-4 animate-pulse" /> VOICE_NUCLEUS_ACTIVE
                </div>
                
                <h2 className="text-4xl lg:text-7xl font-black text-white leading-[0.9] tracking-tighter uppercase">
                  EXPERIENCE <br />
                  <span className="text-teal-500">VOICE AI</span> QUALITY.
                </h2>
                
                <p className="text-slate-400 text-lg leading-relaxed font-medium">
                  Experience the standard of communication WinDeal brings to your campaigns. Talk to our Gemini-powered Sales Trainer in real-time to witness our linguistic excellence.
                </p>

                <div className="flex flex-wrap gap-6 justify-center lg:justify-start">
                  {[
                    { icon: <Shield className="w-4 h-4" />, label: "TCPA COMPLIANT" },
                    { icon: <Zap className="w-4 h-4" />, label: "ZERO LATENCY" },
                    { icon: <Globe className="w-4 h-4" />, label: "USA ACCENT" }
                  ].map((feat, i) => (
                    <div key={i} className="flex items-center gap-3 text-slate-500 font-black text-[10px] tracking-widest uppercase bg-white/5 px-5 py-3 rounded-2xl border border-white/5">
                      {feat.icon} {feat.label}
                    </div>
                  ))}
                </div>
              </div>

              <div className="lg:w-1/2 w-full">
                <div className="relative aspect-square max-w-[450px] mx-auto group">
                  {/* Outer Rings */}
                  <div className={`absolute inset-0 rounded-full border-2 border-teal-500/20 scale-100 ${isActive ? 'animate-ping' : ''}`}></div>
                  <div className={`absolute inset-0 rounded-full border border-emerald-500/10 scale-110 ${isActive ? 'animate-pulse' : ''}`}></div>
                  
                  {/* Main Interface */}
                  <div className={`h-full w-full rounded-full bg-slate-900 border-8 ${isActive ? 'border-teal-500/50' : 'border-slate-800'} flex flex-col items-center justify-center relative overflow-hidden transition-all duration-700 shadow-[0_0_80px_rgba(13,148,136,0.1)]`}>
                    
                    {/* Audio Visualizer Waves */}
                    <div className="flex gap-1.5 items-center justify-center h-24 mb-6">
                      {Array.from({ length: 12 }).map((_, i) => (
                        <div 
                          key={i} 
                          className={`w-2 bg-gradient-to-t from-teal-500 to-emerald-400 rounded-full transition-all duration-100 ${!isActive ? 'h-2 opacity-20' : ''}`}
                          style={{ height: isActive ? `${Math.max(10, (audioLevel * 500) * (Math.sin(i + Date.now()/100) + 1.2))}%` : '8px' }}
                        ></div>
                      ))}
                    </div>

                    <button
                      onClick={startVoiceExperience}
                      disabled={isConnecting}
                      className={`relative z-10 w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500 transform hover:scale-110 active:scale-95 ${
                        isActive 
                          ? 'bg-rose-500 text-white shadow-[0_0_40px_rgba(244,63,94,0.4)]' 
                          : isConnecting 
                            ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                            : 'bg-teal-600 text-white shadow-[0_0_40px_rgba(13,148,136,0.4)]'
                      }`}
                    >
                      {isConnecting ? (
                        <div className="animate-spin rounded-full h-8 w-8 border-4 border-white/30 border-t-white"></div>
                      ) : isActive ? (
                        <MicOff className="w-10 h-10" />
                      ) : (
                        <Mic className="w-10 h-10" />
                      )}
                    </button>

                    <div className="mt-8 text-center px-10">
                      <div className="text-[10px] font-black tracking-[0.3em] text-teal-500 mb-2 uppercase">
                        {isActive ? 'Live Interaction' : isConnecting ? 'Establishing Link' : 'System Ready'}
                      </div>
                      <div className="text-white font-mono text-xs h-12 overflow-hidden italic opacity-70">
                        {isActive ? (transcript || 'Listening for your voice...') : 'Click mic to simulate a call center interaction'}
                      </div>
                    </div>

                    {/* Background Glow */}
                    <div className={`absolute inset-0 -z-10 bg-gradient-to-t from-teal-500/10 to-transparent transition-opacity duration-1000 ${isActive ? 'opacity-100' : 'opacity-0'}`}></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-teal-400">
                  <Volume2 className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <div className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Audio Stream</div>
                  <div className="text-xs text-white font-bold uppercase tracking-tight">HD_Lossless_PCM</div>
                </div>
              </div>
              <div className="flex items-center gap-2 text-slate-600 text-[10px] font-black tracking-widest uppercase">
                <Info className="w-4 h-4" /> Microphone access required for demonstration
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VoiceAIExperience;
