
import React from 'react';
import { 
  Zap, 
  Target, 
  Headset, 
  UserCheck, 
  Cpu, 
  CalendarCheck,
  ArrowRight,
  Database,
  Globe,
  TrendingUp
} from 'lucide-react';
import { ViewType } from '../App';

interface ServicesProps {
  onNavigate: (view: ViewType) => void;
}

const Services: React.FC<ServicesProps> = ({ onNavigate }) => {
  const services = [
    {
      icon: <Zap className="w-8 h-8" />,
      title: "USA Telemarketing",
      desc: "Drive massive volume with high-velocity cold calling. Our agents are trained in Western cultural nuances to bypass gatekeepers effectively.",
      stats: "30-50 Leads/Mo",
      bestFor: "Solar, Insurance, Debt",
      color: "from-blue-500 to-cyan-500",
      shadow: "shadow-blue-500/20"
    },
    {
      icon: <CalendarCheck className="w-8 h-8" />,
      title: "Appointment Setting",
      desc: "Fill your sales team's calendar with qualified prospects. We handle the friction of outreach so your closers focus on winning.",
      stats: "High Quality",
      bestFor: "Real Estate, B2B SaaS",
      color: "from-cyan-500 to-blue-500",
      shadow: "shadow-cyan-500/20"
    },
    {
      icon: <Database className="w-8 h-8" />,
      title: "MCA Lead Generation",
      desc: "Verified business data and real-time live transfers for the Merchant Cash Advance vertical. Pre-qualified for revenue metrics.",
      stats: "FinTech Leads",
      bestFor: "Business Lending",
      color: "from-indigo-600 to-blue-700",
      shadow: "shadow-indigo-600/20"
    },
    {
      icon: <Headset className="w-8 h-8" />,
      title: "Customer Support",
      desc: "24/7 Omni-channel support solutions. We protect your brand reputation with professional, empathetic communication.",
      stats: "99% CSAT",
      bestFor: "E-commerce, Tech Support",
      color: "from-blue-600 to-cyan-700",
      shadow: "shadow-blue-600/20"
    },
    {
      icon: <UserCheck className="w-8 h-8" />,
      title: "Virtual Assistant",
      desc: "Dedicated remote professionals to handle administrative, scheduling, and operational tasks, scaling your efficiency remotely.",
      stats: "Admin Experts",
      bestFor: "Busy Executives, Small Biz",
      color: "from-cyan-400 to-blue-500",
      shadow: "shadow-cyan-400/20"
    },
    {
      icon: <Cpu className="w-8 h-8" />,
      title: "IT & CRM Integration",
      desc: "Full technical setup of CRM architectures and high-speed dialer infrastructures. Custom IT solutions for modern BPO operations.",
      stats: "Tech-Driven",
      bestFor: "Startup Ops, Tech Scaleups",
      color: "from-blue-700 to-slate-800",
      shadow: "shadow-blue-700/20"
    }
  ];

  return (
    <section className="py-32 bg-slate-50 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-blue-100 rounded-full blur-[100px] -mr-48 -mt-48 opacity-60"></div>
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-cyan-100 rounded-full blur-[100px] -ml-48 -mb-48 opacity-60"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row items-end justify-between mb-24 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-4xl lg:text-7xl font-black text-slate-900 mb-8 leading-tight tracking-tighter uppercase">
              REVENUE <br />
              <span className="text-gradient">SERVICES</span>
            </h2>
            <p className="text-slate-500 font-medium text-xl leading-relaxed">
              Precision-engineered BPO and IT solutions tailored for international market dominance and measurable conversion growth.
            </p>
          </div>
          <div className="hidden lg:flex items-center gap-4 bg-white p-4 rounded-3xl border border-slate-100 shadow-sm">
             <div className="w-10 h-10 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-600">
               <TrendingUp className="w-5 h-5" />
             </div>
             <div>
               <div className="text-[10px] font-black text-slate-400 tracking-widest uppercase">System Status</div>
               <div className="text-xs font-bold text-slate-900">Campaign Nodes: ACTIVE</div>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, idx) => (
            <div 
              key={idx} 
              onClick={() => onNavigate('services')}
              className="group relative p-10 rounded-[40px] bg-white border border-slate-100 transition-all hover:translate-y-[-10px] cursor-pointer colorful-shadow flex flex-col h-full overflow-hidden"
            >
              <div className={`absolute top-0 left-0 w-full h-2 bg-gradient-to-r ${service.color}`}></div>
              
              <div className="flex justify-between items-start mb-8">
                <div className={`p-5 rounded-2xl bg-gradient-to-br ${service.color} w-fit shadow-xl ${service.shadow} group-hover:scale-110 transition-transform`}>
                  <div className="text-white">
                    {service.icon}
                  </div>
                </div>
                <div className="px-3 py-1 bg-slate-50 rounded-full text-[9px] font-black text-slate-400 tracking-widest uppercase border border-slate-100">
                  {service.bestFor}
                </div>
              </div>
              
              <h3 className="text-2xl font-black text-slate-900 mb-4 tracking-tight group-hover:text-blue-600 transition-colors uppercase">
                {service.title}
              </h3>
              
              <p className="text-slate-500 mb-10 leading-relaxed font-medium text-sm flex-grow">
                {service.desc}
              </p>
              
              <div className="flex items-center justify-between pt-8 border-t border-slate-50">
                <span className="text-[10px] font-black tracking-widest text-blue-600 uppercase">
                  {service.stats}
                </span>
                <div className="text-blue-600 translate-x-4 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all">
                  <ArrowRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
